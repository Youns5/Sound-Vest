const walletBalance = document.getElementById('walletBalance');
const searchInput = document.getElementById('searchInput');
const walletKey = 'soundvest-wallet';
let wallet = Number(localStorage.getItem(walletKey) || 120);

function updateWallet() {
  walletBalance.textContent = `${wallet} SC`;
  localStorage.setItem(walletKey, String(wallet));
}

updateWallet();

document.querySelectorAll('.invest-btn, .mini-invest').forEach((button) => {
  button.addEventListener('click', () => {
    const artist = button.dataset.artist;
    const amount = Number(button.dataset.amount);

    if (!artist || !amount) {
      return;
    }

    if (wallet < amount) {
      alert(`Tu n’as pas assez de SoundCoins pour investir dans ${artist}.`);
      return;
    }

    wallet -= amount;
    updateWallet();

    const card = button.closest('.artist-card');
    const investedValue = card.querySelector('.invested-value');
    const currentInvested = Number(investedValue.dataset.value || 0);
    const newTotal = currentInvested + amount;

    investedValue.dataset.value = String(newTotal);
    investedValue.textContent = `${newTotal} SC`;

    const trend = card.querySelector('.trend');
    trend.textContent = 'Investi';
    trend.classList.remove('trend-good', 'trend-medium');
    trend.classList.add('trend-good');

    alert(`Merci ! Tu as investi ${amount} SoundCoins dans ${artist}.`);
  });
});

searchInput.addEventListener('input', (event) => {
  const query = event.target.value.trim().toLowerCase();

  document.querySelectorAll('.artist-card').forEach((card) => {
    const artistName = card.dataset.name.toLowerCase();
    const genre = card.dataset.genre.toLowerCase();
    const match = artistName.includes(query) || genre.includes(query);

    card.classList.toggle('hidden', !match && query !== '');
  });
});

document.querySelectorAll('.comment-form').forEach((form) => {
  form.addEventListener('submit', (event) => {
    event.preventDefault();

    const input = form.querySelector('input');
    const text = input.value.trim();

    if (!text) {
      return;
    }

    const list = form.closest('.community-box').querySelector('.comment-list');
    const item = document.createElement('li');
    item.textContent = `“${text}”`;
    list.appendChild(item);
    input.value = '';
  });
});
