# Soundvest

Soundvest est un petit site de démonstration pour découvrir des artistes, écouter un extrait, regarder leur évolution, et investir avec une monnaie virtuelle.

Le but du projet n’est pas d’avoir un rendu trop technique ni trop “showcase”. On veut un site simple, lisible, presque naturel, avec une interface claire et un côté très accessible.

## Ce que le site fait

- affiche une page d’accueil avec des artistes
- permet de chercher un artiste par son nom ou son style
- permet d’écouter un morceau d’exemple
- montre une courbe de progression pour chaque artiste
- affiche un score visuel de popularité
- donne un portefeuille virtuel en SoundCoins
- permet d’investir un montant choisi
- permet d’ajouter un commentaire dans la communauté de l’artiste

## Design actuel

Le design a été simplifié pour éviter le côté trop “IA / startup / trop parfait”.

On est passé vers une direction plus douce et plus naturelle :

- fond beige clair
- couleurs sobres et terreuses
- boutons simples
- cartes plus lisibles
- moins de gradients agressifs
- texte plus direct et moins marketing

Le but est de faire un site qui a l’air humain, authentique, et facile à comprendre.

## Comment lancer le projet

Il suffit d’ouvrir le fichier `index.html` dans un navigateur.

Si tu veux, tu peux aussi lancer un petit serveur local, mais pour ce projet, ouvrir le fichier HTML directement est suffisant.

## Structure du projet

### `index.html`

C’est le fichier principal. Il contient :

- le header avec le logo et le portefeuille
- la section d’introduction
- les cartes d’artistes
- le bloc d’écoute audio
- les boutons d’investissement
- les zones de commentaires
- la recherche

C’est la base du site.

### `styles.css`

Le CSS gère le look général du site :

- les couleurs
- les cartes artistes
- les boutons
- les blocs de texte
- la mise en page
- le responsive mobile

Il a été ajusté pour donner un rendu plus naturel et moins “générique”.

### `script.js`

Le JavaScript gère l’interactivité :

- le portefeuille virtuel
- l’investissement dans un artiste
- la recherche
- l’ajout de commentaires

## Explication du JavaScript

### 1. Portefeuille virtuel

```js
let wallet = Number(localStorage.getItem(walletKey) || 120);
```

Le portefeuille commence à 120 SoundCoins.

```js
function updateWallet() {
  walletBalance.textContent = `${wallet} SC`;
  localStorage.setItem(walletKey, String(wallet));
}
```

Cette fonction met à jour l’affichage du solde et le sauvegarde dans le navigateur.

### 2. Investir un artiste

```js
document.querySelectorAll('.invest-btn, .mini-invest').forEach((button) => {
```

On sélectionne tous les boutons d’investissement.

```js
const amount = Number(button.dataset.amount);
```

Le montant vient directement du HTML.

```js
if (wallet < amount) {
  alert(`Tu n’as pas assez de SoundCoins pour investir dans ${artist}.`);
  return;
}
```

Si le solde est trop bas, on bloque l’investissement.

```js
wallet -= amount;
```

On retire l’argent du portefeuille virtuel.

### 3. Recherche d’artiste

```js
const query = event.target.value.trim().toLowerCase();
```

On récupère la recherche et on la met en minuscule.

```js
const match = artistName.includes(query) || genre.includes(query);
```

On compare avec le nom ou le style de l’artiste.

### 4. Ajouter un commentaire

```js
const item = document.createElement('li');
item.textContent = `“${text}”`;
list.appendChild(item);
```

On crée un nouveau commentaire dans la liste de commentaires.

## Explication du HTML

Chaque carte artiste contient :

- une photo
- le nom
- le style musical
- une petite description
- quelques chiffres
- une courbe visuelle
- un lecteur audio
- un bouton d’investissement
- une zone de commentaires

Le site reste simple, mais il comprend déjà la logique principale du concept.

## Explication du CSS

Le CSS permet de faire le rendu visuel. On y trouve :

- la palette de couleurs
- les cartes
- les boutons
- le header et le portefeuille
- les sections d’introduction
- le design responsive pour mobile

Le style a été volontairement rendu plus discret et plus “naturel”.

## Ce qu’on peut faire ensuite

- ajouter plus d’artistes
- remplacer les images de démonstration par des vraies photos
- ajouter un vrai système de compte / inscription
- créer une vraie page détail pour chaque artiste
- améliorer la logique de portefeuille et de gestion utilisateur

## Conclusion

Soundvest est un prototype simple, mais il montre bien l’idée : écouter, comparer, suivre et soutenir des artistes avec un système de funding très accessible.

Le but est surtout d’avoir un site clair et crédible, sans trop de fioritures, ce qui est déjà bien pour une première version.
